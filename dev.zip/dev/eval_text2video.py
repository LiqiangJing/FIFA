import json
import os
import openai
import pandas as pd
import string
from typing import Any, Callable, Dict, List, Optional
from pathlib import Path
import openai
from utils_text2video import generate_dsg
import tqdm
import time
from parse_utils import parse_tuple_output, parse_dependency_output, parse_question_output
import re

os.environ["CUDA_VISIBLE_DEVICES"] = "2"  # 只使用 GPU 0

NUM_SECONDS_TO_SLEEP = 10



def openai_completion(prompt, model='gpt-4o', max_tokens: int = 1024):
    while True:
        try:
            response = client.chat.completions.create(
                model=model,
                messages=[{
                    'role': 'system',
                    'content': 'You are a language assistant.'
                }, {
                    'role': 'user',
                    'content': prompt,
                }],
                temperature=0,
                max_tokens=max_tokens,
                top_p=1,
            )
            break
        # except openai.error.RateLimitError:
        #     pass
        except Exception as e:
            print(e)
        time.sleep(NUM_SECONDS_TO_SLEEP)
    if response.usage.total_tokens > 7000:
        print(response.usage.prompt_tokens, response.usage.total_tokens)
    return response.choices[0].message.content

i=0
id2prompts = {}
with open("prompts_text2video.json", "r") as f:
    for line in f:
        i += 1
        line = eval(line)
        if line['id'] in id2prompts:
            print(line['id'])
        id2prompts[line['id']] = {}
        id2prompts[line['id']]['input'] = line['prompt']
        if i>=1:
            break


task_name = "text2video"

model_name = "cogvideox"
# model_name = "hunyuanvideo"

# dataset_name = "msrvtt_50"
dataset_name = "msrvtt"
# print(id2prompts)
# id2prompts = {'video6518':id2prompts['video6518']}
# id2prompts

id2tuple_outputs, id2question_outputs, id2dependency_outputs = generate_dsg(
    id2prompts,
    openai_completion,
    verbose=False,
    N_parallel_workers=5,
)


if not os.path.exists(f"results/{task_name}/{dataset_name}"):
    os.makedirs(f"results/{task_name}/{dataset_name}")
with open(f"results/{task_name}/{dataset_name}/id2tuple_outputs_{model_name}.json", "w") as f:
    json.dump(id2tuple_outputs, f, indent="\t")
with open(f"results/{task_name}/{dataset_name}/id2question_outputs_{model_name}.json", "w") as f:
    json.dump(id2question_outputs, f, indent="\t")
with open(f"results/{task_name}/{dataset_name}/id2dependency_outputs_{model_name}.json", "w") as f:
    json.dump(id2dependency_outputs, f, indent="\t")
exit()


with open(f"results/{task_name}/{dataset_name}/id2tuple_outputs_{model_name}.json", "r") as f:
    id2tuple_outputs = eval(f.read())
with open(f"results/{task_name}/{dataset_name}/id2question_outputs_{model_name}.json", "r") as f:
    id2question_outputs = eval(f.read())
with open(f"results/{task_name}/{dataset_name}/id2dependency_outputs_{model_name}.json", "r") as f:
    id2dependency_outputs = eval(f.read())



with open("/home/lxj220018/DSG/Instruction/instruction_cogvideox_filtered.json", "r") as f:
    data_filtered = json.load(f)

from video_qa import video_question_answering_internvl

results_vqa = {}
i = 0
for key in tqdm.tqdm(id2prompts.keys()):
    i = i + 1
    if key not in data_filtered:
        print(f"jump {key}")
        continue
    # if i < 180:
    #     continue
    # print(id2question_outputs[key]['output'])
    # print(id2dependency_outputs[key]['output'])
    # print(id2tuple_outputs[key]['output'])
    qid2question = parse_question_output(id2question_outputs[key]['output'])
    qid2dependency = parse_dependency_output(id2dependency_outputs[key]['output'])
    qid2tuple = parse_tuple_output(id2tuple_outputs[key]['output'])
    if model_name == "hunyuanvideo":
        video_path = os.path.join("/home/lxj220018/text2video/HunyuanVideo/results", key + "_hunyuanvideo.mp4")
    elif model_name == "cogvideox":
        # video_path = os.path.join("/home/lxj220018/text2video/inference/results", key + "_cogvideox.mp4")

        instruct = data_filtered[key]["instruct"]
        prompt = data_filtered[key]['prompt']
        # 提取 inversion_prompt（从 instruct 中提取###中间的内容，如果没有就用空字符串）
        match = re.search(r'###\s*(.*?)\s*###', instruct)
        if match:
            prompt_text = match.group(1).strip()
        video_path = f"/home/lxj220018/video_edit/TokenFlow/tokenflow-results_pnp_SD_2.1/instruct/{key}_cogvideox/{prompt_text}/attn_0.5_f_0.8/batch_size_8/50/tokenflow_PnP_fps_10.mp4"
        video_path = f"/home/lxj220018/video_edit/TokenFlow/tokenflow-results_pnp_SD_2.1/{key}_cogvideox/{prompt}/attn_0.5_f_0.8/batch_size_8/50/tokenflow_PnP_fps_10.mp4"



    qid2answer = {}
    qid2scores = {}
    qid2validity = {}

    for id, question in qid2question.items():
        answer = video_question_answering_internvl(question, video_path)
        qid2answer[id] = answer
        qid2scores[id] = float('yes' in answer.lower())

    average_score_without_dep = sum(qid2scores.values()) / len(qid2scores)
    # print(qid2question)
    # print(qid2dependency, qid2scores)

    for id, parent_ids in qid2dependency.items():
        if id > len(qid2question):
            print(key)
            continue
        # zero-out scores if parent questions are answered 'no'
        any_parent_answered_no = False
        for parent_id in parent_ids:
            if parent_id == 0:
                continue
            if qid2scores[parent_id] == 0:
                any_parent_answered_no = True
                break
        if any_parent_answered_no:
            qid2scores[id] = 0
            qid2validity[id] = False
        else:
            qid2validity[id] = True

    results_vqa[key] = {"qid2answer": qid2answer, "qid2scores": qid2scores, "qid2validity": qid2validity,
                        "average_score_without_dep": average_score_without_dep,
                        "average_score": sum(qid2scores.values()) / len(qid2scores)}
print(f"final results {sum([results_vqa[key]['average_score'] for key in results_vqa]) / len(results_vqa)}")

with open(f"results/{task_name}/corrected/vqa_results_{model_name}_prompt.json", "w") as f:
    json.dump(results_vqa, f, indent="\t")

# with open(f"results/{task_name}/{dataset_name}/vqa_results_{model_name}.json", "w") as f:
#     json.dump(results_vqa, f, indent="\t")



